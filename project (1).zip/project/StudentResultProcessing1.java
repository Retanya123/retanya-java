import java.util.Scanner;

class StudentRecord {

    int rollNo;
    String name;
    int[] marks = new int[5];

    StudentRecord(int rollNo, String name, int[] marks) {
        this.rollNo = rollNo;
        this.name = name;
        this.marks = marks;
    }

    int getTotal() {
        int total = 0;
        for (int m : marks) {
            total += m;
        }
        return total;
    }

    double getAverage() {
        return getTotal() / 5.0;
    }
}

public class StudentResultProcessing1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Roll No: ");
        int roll = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Name: ");
        String name = sc.nextLine();

        int[] marks = new int[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter mark for subject " + (i + 1) + ": ");
            marks[i] = sc.nextInt();
        }

        StudentRecord s = new StudentRecord(roll, name, marks);

        System.out.println("Total: " + s.getTotal());
        System.out.println("Average: " + s.getAverage());

        sc.close();
    }
}