import java.util.ArrayList;
import java.util.Scanner;

class AcademicResult {

    int id;
    String studentName;
    double internalMarks;
    double examMarks;

    AcademicResult(int id, String studentName, double internalMarks, double examMarks) {
        this.id = id;
        this.studentName = studentName;
        this.internalMarks = internalMarks;
        this.examMarks = examMarks;
    }

    double finalScore() {
        return (internalMarks * 0.4) + (examMarks * 0.6);
    }

    String performanceLevel() {
        double score = finalScore();

        if (score >= 90) return "Outstanding";
        else if (score >= 75) return "Excellent";
        else if (score >= 60) return "Good";
        else if (score >= 50) return "Average";
        else return "Needs Improvement";
    }

    void display() {
        System.out.println("\nID        : " + id);
        System.out.println("Name      : " + studentName);
        System.out.println("FinalScore: " + finalScore());
        System.out.println("Level     : " + performanceLevel());
    }
}

public class StudentResultProcessing2 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ArrayList<AcademicResult> list = new ArrayList<>();

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {

            System.out.println("\nEnter Student " + (i + 1));

            System.out.print("ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Name: ");
            String name = sc.nextLine();

            System.out.print("Internal Marks (50): ");
            double internal = sc.nextDouble();

            System.out.print("Exam Marks (100): ");
            double exam = sc.nextDouble();

            list.add(new AcademicResult(id, name, internal, exam));
        }

        double highest = 0;
        String topper = "";

        System.out.println("\n===== PERFORMANCE REPORT =====");

        for (AcademicResult a : list) {
            a.display();

            if (a.finalScore() > highest) {
                highest = a.finalScore();
                topper = a.studentName;
            }
        }

        System.out.println("\nTop Performer: " + topper + " (" + highest + ")");

        sc.close();
    }
}